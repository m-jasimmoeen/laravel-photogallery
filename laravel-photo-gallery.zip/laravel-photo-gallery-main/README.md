# Laravel Photo Gallery

## Clone the Repository

Run the Command
`composer install`
### Create .env file
create the database and add to .env file
Run the `php artisan key:generate` to generate the key
Run the `php artisan migrate`to migrate database
Run th `php artisan storage:lnik` to make alias of storage folder on public directory
## Lunch the Application
## Enjoy happy code
